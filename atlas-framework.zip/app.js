// Cloud Infrastructure Orchestration Dashboard
const { useState, useEffect, useRef, createContext, useContext } = React;

// Sample Data
const sampleInstances = [
  {
    id: "i-0a1b2c3d4e5f6",
    provider: "AWS",
    type: "c5.2xlarge",
    region: "us-east-1",
    regionName: "US East (Virginia)",
    status: "running",
    publicIp: "54.123.45.67",
    privateIp: "10.0.1.45",
    cpuUsage: 45.2,
    memoryUsage: 62.8,
    networkIn: 1250000,
    networkOut: 890000,
    costPerHour: 0.34,
    lat: 38.13,
    lon: -78.45
  },
  {
    id: "i-9z8y7x6w5v4u3",
    provider: "AWS",
    type: "c5.xlarge",
    region: "us-west-2",
    regionName: "US West (Oregon)",
    status: "running",
    publicIp: "34.210.12.89",
    privateIp: "10.0.2.12",
    cpuUsage: 28.5,
    memoryUsage: 51.3,
    networkIn: 890000,
    networkOut: 450000,
    costPerHour: 0.17,
    lat: 45.87,
    lon: -119.69
  },
  {
    id: "gcp-inst-abc123",
    provider: "GCP",
    type: "n2-standard-4",
    region: "us-central1",
    regionName: "US Central (Iowa)",
    status: "running",
    publicIp: "35.192.45.120",
    privateIp: "10.128.0.5",
    cpuUsage: 67.9,
    memoryUsage: 73.1,
    networkIn: 2100000,
    networkOut: 1800000,
    costPerHour: 0.19,
    lat: 41.26,
    lon: -95.86
  },
  {
    id: "i-7f8g9h0i1j2k3",
    provider: "AWS",
    type: "t3.medium",
    region: "eu-west-1",
    regionName: "EU West (Ireland)",
    status: "stopped",
    publicIp: "52.210.45.123",
    privateIp: "10.0.3.78",
    cpuUsage: 0,
    memoryUsage: 0,
    networkIn: 0,
    networkOut: 0,
    costPerHour: 0.0416,
    lat: 53.35,
    lon: -6.26
  },
  {
    id: "gcp-inst-def456",
    provider: "GCP",
    type: "n1-standard-2",
    region: "europe-west1",
    regionName: "Europe West (Belgium)",
    status: "running",
    publicIp: "35.195.123.89",
    privateIp: "10.132.0.8",
    cpuUsage: 34.7,
    memoryUsage: 58.2,
    networkIn: 567000,
    networkOut: 234000,
    costPerHour: 0.095,
    lat: 50.85,
    lon: 4.35
  },
  {
    id: "i-4l5m6n7o8p9q0",
    provider: "AWS",
    type: "m5.large",
    region: "ap-southeast-1",
    regionName: "Asia Pacific (Singapore)",
    status: "running",
    publicIp: "13.250.89.156",
    privateIp: "10.0.4.23",
    cpuUsage: 52.3,
    memoryUsage: 47.8,
    networkIn: 1890000,
    networkOut: 1234000,
    costPerHour: 0.096,
    lat: 1.35,
    lon: 103.82
  }
];

const cloudRegions = {
  aws: [
    { code: "us-east-1", name: "US East (Virginia)", lat: 38.13, lon: -78.45 },
    { code: "us-west-2", name: "US West (Oregon)", lat: 45.87, lon: -119.69 },
    { code: "eu-west-1", name: "EU West (Ireland)", lat: 53.35, lon: -6.26 },
    { code: "ap-southeast-1", name: "Asia Pacific (Singapore)", lat: 1.35, lon: 103.82 },
    { code: "ap-northeast-1", name: "Asia Pacific (Tokyo)", lat: 35.68, lon: 139.77 }
  ],
  gcp: [
    { code: "us-central1", name: "US Central (Iowa)", lat: 41.26, lon: -95.86 },
    { code: "europe-west1", name: "Europe West (Belgium)", lat: 50.85, lon: 4.35 },
    { code: "asia-east1", name: "Asia East (Taiwan)", lat: 25.03, lon: 121.56 },
    { code: "australia-southeast1", name: "Australia Southeast (Sydney)", lat: -33.87, lon: 151.21 }
  ]
};

const vpnConfigs = [
  {
    id: 1,
    instanceId: "i-0a1b2c3d4e5f6",
    type: "wireguard",
    endpoint: "54.123.45.67:51820",
    publicKey: "xYz123aBc456dEf789gHi012jKl345mNo678pQr901sTu234=",
    status: "active",
    uploadBytes: 15600000,
    downloadBytes: 8900000
  },
  {
    id: 2,
    instanceId: "i-9z8y7x6w5v4u3",
    type: "wireguard",
    endpoint: "34.210.12.89:51820",
    publicKey: "vWx987yZa654bCd321eFg098hIj765kLm432nOp109qRs876=",
    status: "active",
    uploadBytes: 8200000,
    downloadBytes: 5100000
  }
];

const workloads = [
  {
    id: 1,
    name: "Security Assessment",
    type: "scan",
    status: "running",
    progress: 67,
    instanceCount: 5,
    totalTargets: 10000,
    completedTargets: 6700,
    startTime: "2025-10-18T19:30:00Z"
  },
  {
    id: 2,
    name: "Network Reconnaissance",
    type: "reconnaissance",
    status: "running",
    progress: 23,
    instanceCount: 3,
    totalTargets: 5000,
    completedTargets: 1150,
    startTime: "2025-10-18T20:15:00Z"
  }
];

// Context for global state
const AppContext = createContext();

// Auth Context
const AuthContext = createContext();

// Toast Context
const ToastContext = createContext();

// Toast Provider Component
function ToastProvider({ children }) {
  const [toasts, setToasts] = useState([]);

  const showToast = (message, type = 'success') => {
    const id = Date.now();
    setToasts(prev => [...prev, { id, message, type }]);
    setTimeout(() => {
      setToasts(prev => prev.filter(toast => toast.id !== id));
    }, 5000);
  };

  return (
    <ToastContext.Provider value={{ showToast }}>
      {children}
      <div className="toast-container">
        {toasts.map(toast => (
          <div key={toast.id} className={`toast ${toast.type}`}>
            {toast.message}
          </div>
        ))}
      </div>
    </ToastContext.Provider>
  );
}

// Auth Provider
function AuthProvider({ children }) {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Check for session token in memory (simulated)
    // Note: In production, this would check a secure session
    setIsAuthenticated(false);
    setLoading(false);
  }, []);

  const login = async (email, password) => {
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    if (email === 'admin@cloud.dev' && password === 'password') {
      // Simulate storing session token (in production, would be handled securely)
      // const token = 'jwt_token_' + Date.now();
      setIsAuthenticated(true);
      return { success: true };
    } else {
      return { success: false, error: 'Invalid credentials' };
    }
  };

  const logout = () => {
    // Clear session (in production, would clear secure session)
    setIsAuthenticated(false);
  };

  return (
    <AuthContext.Provider value={{ isAuthenticated, login, logout, loading }}>
      {children}
    </AuthContext.Provider>
  );
}

// Main App Provider
function AppProvider({ children }) {
  const [instances, setInstances] = useState(sampleInstances);
  const [currentPage, setCurrentPage] = useState('dashboard');
  const [selectedInstances, setSelectedInstances] = useState([]);
  const [workloadList, setWorkloadList] = useState(workloads);
  const [vpnList, setVpnList] = useState(vpnConfigs);

  // Simulate real-time updates
  useEffect(() => {
    const interval = setInterval(() => {
      setInstances(prev => prev.map(instance => ({
        ...instance,
        cpuUsage: Math.max(10, Math.min(90, instance.cpuUsage + (Math.random() - 0.5) * 10)),
        memoryUsage: Math.max(20, Math.min(85, instance.memoryUsage + (Math.random() - 0.5) * 8)),
        networkIn: Math.max(100000, instance.networkIn + Math.random() * 200000 - 100000),
        networkOut: Math.max(50000, instance.networkOut + Math.random() * 150000 - 75000)
      })));
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  return (
    <AppContext.Provider value={{
      instances,
      setInstances,
      currentPage,
      setCurrentPage,
      selectedInstances,
      setSelectedInstances,
      workloadList,
      setWorkloadList,
      vpnList,
      setVpnList
    }}>
      {children}
    </AppContext.Provider>
  );
}

// Login Component
function LoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const { login } = useContext(AuthContext);
  const { showToast } = useContext(ToastContext);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    const result = await login(email, password);
    
    if (result.success) {
      showToast('Login successful!', 'success');
    } else {
      setError(result.error);
    }
    
    setLoading(false);
  };

  return (
    <div className="login-container">
      <div className="login-card">
        <div className="login-header">
          <h1 className="login-title">☁️ Cloud Orchestrator</h1>
          <p className="login-subtitle">Sign in to your dashboard</p>
        </div>
        
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label className="form-label">Email</label>
            <input
              type="email"
              className="form-input"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="admin@cloud.dev"
              required
            />
          </div>
          
          <div className="form-group">
            <label className="form-label">Password</label>
            <input
              type="password"
              className="form-input"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="password"
              required
            />
          </div>
          
          {error && (
            <div className="form-group">
              <p style={{ color: 'var(--color-error)', fontSize: 'var(--font-size-sm)' }}>
                {error}
              </p>
            </div>
          )}
          
          <div className="form-group">
            <div className="form-checkbox">
              <input type="checkbox" className="checkbox" />
              <label className="checkbox-label">Remember me</label>
            </div>
          </div>
          
          <button type="submit" className="btn btn-primary btn-full" disabled={loading}>
            {loading ? 'Signing in...' : 'Sign In'}
          </button>
        </form>
        
        <div className="mt-16 text-sm text-muted" style={{ textAlign: 'center' }}>
          Demo credentials: admin@cloud.dev / password
        </div>
      </div>
    </div>
  );
}

// Sidebar Component
function Sidebar() {
  const { currentPage, setCurrentPage } = useContext(AppContext);
  const { logout } = useContext(AuthContext);
  const { showToast } = useContext(ToastContext);

  const navItems = [
    { id: 'dashboard', name: 'Dashboard', icon: '📊' },
    { id: 'map', name: 'World Map', icon: '🗺️' },
    { id: 'fleet', name: 'Fleet Manager', icon: '☁️' },
    { id: 'vpn', name: 'VPN Dashboard', icon: '🔒' },
    { id: 'workloads', name: 'Workload Scheduler', icon: '⚡' },
    { id: 'costs', name: 'Cost Tracker', icon: '💰' },
    { id: 'settings', name: 'Settings', icon: '⚙️' }
  ];

  const handleLogout = () => {
    logout();
    showToast('Logged out successfully', 'success');
  };

  return (
    <div className="sidebar">
      <div className="sidebar-header">
        <div className="sidebar-logo">
          <span>☁️</span>
          <span>Cloud Orchestrator</span>
        </div>
      </div>
      
      <nav className="sidebar-nav">
        {navItems.map(item => (
          <a
            key={item.id}
            className={`nav-item ${currentPage === item.id ? 'active' : ''}`}
            onClick={() => setCurrentPage(item.id)}
          >
            <span className="nav-item-icon">{item.icon}</span>
            <span>{item.name}</span>
          </a>
        ))}
        
        <div style={{ marginTop: 'auto' }}>
          <a className="nav-item" onClick={handleLogout}>
            <span className="nav-item-icon">🚪</span>
            <span>Logout</span>
          </a>
        </div>
      </nav>
    </div>
  );
}

// Header Component
function Header({ title }) {
  return (
    <div className="main-header">
      <h1 className="header-title">{title}</h1>
      <div className="header-actions">
        <div className="text-sm text-muted">
          Last updated: {new Date().toLocaleTimeString()}
        </div>
      </div>
    </div>
  );
}

// Dashboard Component
function Dashboard() {
  const { instances } = useContext(AppContext);
  
  const runningInstances = instances.filter(i => i.status === 'running').length;
  const totalCost = instances.reduce((sum, i) => sum + i.costPerHour, 0) * 24 * 30;
  const totalVpns = vpnConfigs.length;
  const activeWorkloads = workloads.filter(w => w.status === 'running').length;

  return (
    <div>
      <div className="metrics-grid">
        <div className="metric-card">
          <div className="metric-value">{runningInstances}</div>
          <div className="metric-label">Running Instances</div>
          <div className="metric-change positive">+2 from yesterday</div>
        </div>
        
        <div className="metric-card">
          <div className="metric-value">${totalCost.toFixed(0)}</div>
          <div className="metric-label">Monthly Cost</div>
          <div className="metric-change positive">-5% from last month</div>
        </div>
        
        <div className="metric-card">
          <div className="metric-value">{totalVpns}</div>
          <div className="metric-label">Active VPNs</div>
          <div className="metric-change">No change</div>
        </div>
        
        <div className="metric-card">
          <div className="metric-value">{activeWorkloads}</div>
          <div className="metric-label">Running Workloads</div>
          <div className="metric-change positive">+1 from yesterday</div>
        </div>
      </div>
      
      <div className="card">
        <div className="card-header">
          <h3 className="card-title">Recent Activity</h3>
        </div>
        <div className="card-body">
          <div className="flex flex-col gap-12">
            <div className="flex items-center gap-12">
              <span className="status-badge running">New</span>
              <span>Instance i-0a1b2c3d4e5f6 deployed in us-east-1</span>
              <span className="text-muted text-sm">2 minutes ago</span>
            </div>
            <div className="flex items-center gap-12">
              <span className="status-badge running">VPN</span>
              <span>WireGuard configuration generated for 34.210.12.89</span>
              <span className="text-muted text-sm">15 minutes ago</span>
            </div>
            <div className="flex items-center gap-12">
              <span className="status-badge running">Workload</span>
              <span>Security Assessment completed 6,700/10,000 targets</span>
              <span className="text-muted text-sm">30 minutes ago</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// World Map Component
function WorldMap() {
  const { instances } = useContext(AppContext);
  const mapRef = useRef(null);
  const leafletMapRef = useRef(null);

  useEffect(() => {
    if (!mapRef.current || leafletMapRef.current) return;

    // Initialize Leaflet map
    const map = L.map(mapRef.current, {
      center: [30, 0],
      zoom: 2,
      zoomControl: true,
      scrollWheelZoom: true
    });

    // Add dark tile layer
    L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
      attribution: '© OpenStreetMap contributors © CARTO',
      maxZoom: 18
    }).addTo(map);

    leafletMapRef.current = map;

    // Add markers for regions
    [...cloudRegions.aws, ...cloudRegions.gcp].forEach(region => {
      const provider = cloudRegions.aws.includes(region) ? 'aws' : 'gcp';
      const regionInstances = instances.filter(i => i.region === region.code);
      const runningCount = regionInstances.filter(i => i.status === 'running').length;
      
      const markerHtml = `
        <div class="custom-marker ${provider} ${runningCount > 0 ? 'active' : ''}">
          ${runningCount}
        </div>
      `;
      
      const marker = L.marker([region.lat, region.lon], {
        icon: L.divIcon({
          html: markerHtml,
          className: 'custom-div-icon',
          iconSize: [30, 30],
          iconAnchor: [15, 15]
        })
      }).addTo(map);
      
      const popupContent = `
        <div style="color: var(--color-text); padding: 8px;">
          <h4>${region.name}</h4>
          <p><strong>Provider:</strong> ${provider.toUpperCase()}</p>
          <p><strong>Instances:</strong> ${regionInstances.length}</p>
          <p><strong>Running:</strong> ${runningCount}</p>
        </div>
      `;
      
      marker.bindPopup(popupContent);
    });

    return () => {
      if (leafletMapRef.current) {
        leafletMapRef.current.remove();
        leafletMapRef.current = null;
      }
    };
  }, [instances]);

  return (
    <div>
      <div className="card mb-24">
        <div className="card-header">
          <h3 className="card-title">Global Infrastructure Distribution</h3>
        </div>
        <div className="card-body">
          <div className="map-container">
            <div ref={mapRef} id="map"></div>
          </div>
        </div>
      </div>
      
      <div className="card">
        <div className="card-header">
          <h3 className="card-title">Region Status</h3>
        </div>
        <div className="card-body">
          <div className="flex gap-16" style={{ flexWrap: 'wrap' }}>
            <div className="flex items-center gap-8">
              <div className="custom-marker aws">AWS</div>
              <span>Amazon Web Services Regions</span>
            </div>
            <div className="flex items-center gap-8">
              <div className="custom-marker gcp">GCP</div>
              <span>Google Cloud Platform Regions</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// Fleet Manager Component
function FleetManager() {
  const { instances, setInstances, selectedInstances, setSelectedInstances } = useContext(AppContext);
  const { showToast } = useContext(ToastContext);
  const [showDeployModal, setShowDeployModal] = useState(false);

  const handleInstanceAction = (instanceId, action) => {
    setInstances(prev => prev.map(instance => 
      instance.id === instanceId 
        ? { ...instance, status: action === 'start' ? 'running' : 'stopped' }
        : instance
    ));
    showToast(`Instance ${instanceId} ${action}ed successfully`, 'success');
  };

  const handleSelectInstance = (instanceId) => {
    setSelectedInstances(prev => 
      prev.includes(instanceId)
        ? prev.filter(id => id !== instanceId)
        : [...prev, instanceId]
    );
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-24">
        <div>
          <h2>Fleet Manager</h2>
          <p className="text-muted">Manage your cloud instances across providers</p>
        </div>
        <button 
          className="btn btn-primary"
          onClick={() => setShowDeployModal(true)}
        >
          Deploy New Fleet
        </button>
      </div>
      
      <div className="card">
        <div className="card-header">
          <h3 className="card-title">Instance Overview ({instances.length} total)</h3>
        </div>
        <div className="table-container">
          <table className="table">
            <thead>
              <tr>
                <th>
                  <input 
                    type="checkbox" 
                    onChange={(e) => setSelectedInstances(
                      e.target.checked ? instances.map(i => i.id) : []
                    )}
                  />
                </th>
                <th>Instance ID</th>
                <th>Provider</th>
                <th>Type</th>
                <th>Region</th>
                <th>Status</th>
                <th>Public IP</th>
                <th>CPU %</th>
                <th>Memory %</th>
                <th>Cost/hr</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {instances.map(instance => (
                <tr key={instance.id}>
                  <td>
                    <input 
                      type="checkbox"
                      checked={selectedInstances.includes(instance.id)}
                      onChange={() => handleSelectInstance(instance.id)}
                    />
                  </td>
                  <td className="font-medium">{instance.id}</td>
                  <td>
                    <span className={`status-badge ${instance.provider.toLowerCase()}`}>
                      {instance.provider}
                    </span>
                  </td>
                  <td>{instance.type}</td>
                  <td>{instance.region}</td>
                  <td>
                    <span className={`status-badge ${instance.status}`}>
                      {instance.status}
                    </span>
                  </td>
                  <td className="font-mono text-sm">{instance.publicIp}</td>
                  <td>{instance.status === 'running' ? `${instance.cpuUsage.toFixed(1)}%` : '-'}</td>
                  <td>{instance.status === 'running' ? `${instance.memoryUsage.toFixed(1)}%` : '-'}</td>
                  <td>${instance.costPerHour}</td>
                  <td>
                    <div className="flex gap-4">
                      {instance.status === 'running' ? (
                        <button 
                          className="btn btn-sm btn-danger"
                          onClick={() => handleInstanceAction(instance.id, 'stop')}
                        >
                          Stop
                        </button>
                      ) : (
                        <button 
                          className="btn btn-sm btn-success"
                          onClick={() => handleInstanceAction(instance.id, 'start')}
                        >
                          Start
                        </button>
                      )}
                      <button className="btn btn-sm btn-secondary">
                        SSH
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      
      {showDeployModal && (
        <DeployModal 
          onClose={() => setShowDeployModal(false)}
          onDeploy={(config) => {
            showToast(`Deploying ${config.quantity} instances in ${config.region}`, 'success');
            setShowDeployModal(false);
          }}
        />
      )}
    </div>
  );
}

// Deploy Modal Component
function DeployModal({ onClose, onDeploy }) {
  const [config, setConfig] = useState({
    provider: 'aws',
    instanceType: 'c5.large',
    region: 'us-east-1',
    quantity: 1
  });

  const instanceTypes = {
    aws: ['t3.micro', 't3.small', 't3.medium', 'c5.large', 'c5.xlarge', 'c5.2xlarge'],
    gcp: ['n1-standard-1', 'n1-standard-2', 'n1-standard-4', 'n2-standard-2', 'n2-standard-4']
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onDeploy(config);
  };

  return (
    <div className="modal-overlay">
      <div className="modal">
        <div className="modal-header">
          <h3 className="modal-title">Deploy New Fleet</h3>
          <button className="modal-close" onClick={onClose}>×</button>
        </div>
        
        <form onSubmit={handleSubmit}>
          <div className="modal-body">
            <div className="form-group">
              <label className="form-label">Cloud Provider</label>
              <select 
                className="form-input"
                value={config.provider}
                onChange={(e) => setConfig({...config, provider: e.target.value})}
              >
                <option value="aws">Amazon Web Services</option>
                <option value="gcp">Google Cloud Platform</option>
              </select>
            </div>
            
            <div className="form-group">
              <label className="form-label">Instance Type</label>
              <select 
                className="form-input"
                value={config.instanceType}
                onChange={(e) => setConfig({...config, instanceType: e.target.value})}
              >
                {instanceTypes[config.provider].map(type => (
                  <option key={type} value={type}>{type}</option>
                ))}
              </select>
            </div>
            
            <div className="form-group">
              <label className="form-label">Region</label>
              <select 
                className="form-input"
                value={config.region}
                onChange={(e) => setConfig({...config, region: e.target.value})}
              >
                {cloudRegions[config.provider].map(region => (
                  <option key={region.code} value={region.code}>{region.name}</option>
                ))}
              </select>
            </div>
            
            <div className="form-group">
              <label className="form-label">Quantity ({config.quantity})</label>
              <input 
                type="range"
                min="1"
                max="10"
                value={config.quantity}
                onChange={(e) => setConfig({...config, quantity: parseInt(e.target.value)})}
                className="form-input"
              />
            </div>
            
            <div className="card" style={{background: 'var(--color-bg-2)', border: 'none'}}>
              <div className="card-body">
                <h4>Estimated Cost</h4>
                <p>~${(config.quantity * 0.096 * 24).toFixed(2)} per day</p>
              </div>
            </div>
          </div>
          
          <div className="modal-footer">
            <button type="button" className="btn btn-secondary" onClick={onClose}>
              Cancel
            </button>
            <button type="submit" className="btn btn-primary">
              Deploy Fleet
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

// VPN Dashboard Component
function VpnDashboard() {
  const { vpnList } = useContext(AppContext);
  const { instances } = useContext(AppContext);
  const { showToast } = useContext(ToastContext);

  const generateConfig = (vpn) => {
    return `[Interface]
PrivateKey = YOUR_PRIVATE_KEY
Address = 10.0.0.2/32
DNS = 1.1.1.1, 8.8.8.8

[Peer]
PublicKey = ${vpn.publicKey}
Endpoint = ${vpn.endpoint}
AllowedIPs = 0.0.0.0/0
PersistentKeepalive = 25`;
  };

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text);
    showToast('Configuration copied to clipboard', 'success');
  };

  const downloadConfig = (vpn) => {
    const config = generateConfig(vpn);
    const blob = new Blob([config], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `wireguard-${vpn.instanceId}.conf`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    showToast('Configuration downloaded', 'success');
  };

  return (
    <div>
      <div className="flex justify-between items-center mb-24">
        <div>
          <h2>VPN Dashboard</h2>
          <p className="text-muted">Manage WireGuard VPN configurations</p>
        </div>
        <button className="btn btn-primary">
          Deploy New VPN
        </button>
      </div>
      
      <div className="metrics-grid mb-24">
        <div className="metric-card">
          <div className="metric-value">{vpnList.length}</div>
          <div className="metric-label">Active VPNs</div>
        </div>
        <div className="metric-card">
          <div className="metric-value">{vpnList.reduce((sum, vpn) => sum + vpn.uploadBytes + vpn.downloadBytes, 0) / 1024 / 1024 / 1024}</div>
          <div className="metric-label">Total Traffic (GB)</div>
        </div>
      </div>
      
      <div className="card">
        <div className="card-header">
          <h3 className="card-title">VPN Configurations</h3>
        </div>
        <div className="card-body">
          <div className="flex flex-col gap-16">
            {vpnList.map(vpn => {
              const instance = instances.find(i => i.id === vpn.instanceId);
              return (
                <div key={vpn.id} className="card">
                  <div className="card-body">
                    <div className="flex justify-between items-start">
                      <div className="flex flex-col gap-8">
                        <div className="flex items-center gap-12">
                          <h4>{instance?.regionName || 'Unknown Region'}</h4>
                          <span className={`status-badge ${vpn.status}`}>{vpn.status}</span>
                        </div>
                        <div className="text-muted text-sm">
                          <p>Endpoint: {vpn.endpoint}</p>
                          <p>Instance: {vpn.instanceId}</p>
                          <p>Upload: {(vpn.uploadBytes / 1024 / 1024).toFixed(1)} MB | Download: {(vpn.downloadBytes / 1024 / 1024).toFixed(1)} MB</p>
                        </div>
                      </div>
                      <div className="flex gap-8">
                        <button 
                          className="btn btn-sm btn-secondary"
                          onClick={() => copyToClipboard(generateConfig(vpn))}
                        >
                          Copy Config
                        </button>
                        <button 
                          className="btn btn-sm btn-secondary"
                          onClick={() => downloadConfig(vpn)}
                        >
                          Download
                        </button>
                        <button className="btn btn-sm btn-secondary">
                          QR Code
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}

// Workload Scheduler Component
function WorkloadScheduler() {
  const { workloadList } = useContext(AppContext);
  const [showCreateModal, setShowCreateModal] = useState(false);

  return (
    <div>
      <div className="flex justify-between items-center mb-24">
        <div>
          <h2>Workload Scheduler</h2>
          <p className="text-muted">Manage distributed workloads across your fleet</p>
        </div>
        <button 
          className="btn btn-primary"
          onClick={() => setShowCreateModal(true)}
        >
          Create Workload
        </button>
      </div>
      
      <div className="card">
        <div className="card-header">
          <h3 className="card-title">Active Workloads</h3>
        </div>
        <div className="card-body">
          <div className="flex flex-col gap-16">
            {workloadList.map(workload => (
              <div key={workload.id} className="card">
                <div className="card-body">
                  <div className="flex justify-between items-start mb-12">
                    <div>
                      <h4>{workload.name}</h4>
                      <p className="text-muted text-sm">
                        {workload.instanceCount} instances • Started {new Date(workload.startTime).toLocaleString()}
                      </p>
                    </div>
                    <span className={`status-badge ${workload.status}`}>
                      {workload.status}
                    </span>
                  </div>
                  
                  <div className="mb-12">
                    <div className="flex justify-between text-sm mb-4">
                      <span>Progress</span>
                      <span>{workload.completedTargets.toLocaleString()} / {workload.totalTargets.toLocaleString()} ({workload.progress}%)</span>
                    </div>
                    <div className="progress-bar">
                      <div className="progress-fill" style={{ width: `${workload.progress}%` }}></div>
                    </div>
                  </div>
                  
                  <div className="flex gap-8">
                    <button className="btn btn-sm btn-secondary">
                      View Details
                    </button>
                    <button className="btn btn-sm btn-danger">
                      Stop
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
      
      {showCreateModal && (
        <CreateWorkloadModal onClose={() => setShowCreateModal(false)} />
      )}
    </div>
  );
}

// Create Workload Modal
function CreateWorkloadModal({ onClose }) {
  const [workload, setWorkload] = useState({
    name: '',
    command: '',
    targets: '',
    strategy: 'round-robin'
  });
  const { showToast } = useContext(ToastContext);

  const handleSubmit = (e) => {
    e.preventDefault();
    showToast(`Workload "${workload.name}" created successfully`, 'success');
    onClose();
  };

  return (
    <div className="modal-overlay">
      <div className="modal">
        <div className="modal-header">
          <h3 className="modal-title">Create New Workload</h3>
          <button className="modal-close" onClick={onClose}>×</button>
        </div>
        
        <form onSubmit={handleSubmit}>
          <div className="modal-body">
            <div className="form-group">
              <label className="form-label">Workload Name</label>
              <input 
                type="text"
                className="form-input"
                value={workload.name}
                onChange={(e) => setWorkload({...workload, name: e.target.value})}
                placeholder="Security Assessment"
                required
              />
            </div>
            
            <div className="form-group">
              <label className="form-label">Command/Script</label>
              <textarea 
                className="form-input"
                rows={4}
                value={workload.command}
                onChange={(e) => setWorkload({...workload, command: e.target.value})}
                placeholder="nmap -sS -O target"
                required
              />
            </div>
            
            <div className="form-group">
              <label className="form-label">Target List</label>
              <textarea 
                className="form-input"
                rows={3}
                value={workload.targets}
                onChange={(e) => setWorkload({...workload, targets: e.target.value})}
                placeholder="192.168.1.0/24\n10.0.0.0/16"
                required
              />
            </div>
            
            <div className="form-group">
              <label className="form-label">Distribution Strategy</label>
              <select 
                className="form-input"
                value={workload.strategy}
                onChange={(e) => setWorkload({...workload, strategy: e.target.value})}
              >
                <option value="round-robin">Round Robin</option>
                <option value="geographic">Geographic Distribution</option>
                <option value="load-balanced">Load Balanced</option>
              </select>
            </div>
          </div>
          
          <div className="modal-footer">
            <button type="button" className="btn btn-secondary" onClick={onClose}>
              Cancel
            </button>
            <button type="submit" className="btn btn-primary">
              Create Workload
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

// Cost Tracker Component
function CostTracker() {
  const { instances } = useContext(AppContext);
  const chartRef = useRef(null);
  const chartInstance = useRef(null);

  useEffect(() => {
    if (chartRef.current && !chartInstance.current) {
      const ctx = chartRef.current.getContext('2d');
      
      chartInstance.current = new Chart(ctx, {
        type: 'line',
        data: {
          labels: ['Oct 1', 'Oct 5', 'Oct 10', 'Oct 15', 'Oct 18'],
          datasets: [{
            label: 'AWS',
            data: [145.23, 156.78, 178.90, 198.45, 212.30],
            borderColor: '#FF9900',
            backgroundColor: 'rgba(255, 153, 0, 0.1)',
            tension: 0.4
          }, {
            label: 'GCP',
            data: [89.45, 92.10, 105.60, 115.20, 125.80],
            borderColor: '#4285F4',
            backgroundColor: 'rgba(66, 133, 244, 0.1)',
            tension: 0.4
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: {
              labels: {
                color: '#f1f5f9'
              }
            }
          },
          scales: {
            x: {
              ticks: {
                color: '#94a3b8'
              },
              grid: {
                color: '#334155'
              }
            },
            y: {
              ticks: {
                color: '#94a3b8',
                callback: function(value) {
                  return '$' + value;
                }
              },
              grid: {
                color: '#334155'
              }
            }
          }
        }
      });
    }

    return () => {
      if (chartInstance.current) {
        chartInstance.current.destroy();
        chartInstance.current = null;
      }
    };
  }, []);

  const totalToday = instances.reduce((sum, i) => sum + i.costPerHour, 0) * 24;
  const totalWeek = totalToday * 7;
  const totalMonth = totalToday * 30;

  return (
    <div>
      <div className="flex justify-between items-center mb-24">
        <div>
          <h2>Cost Tracker</h2>
          <p className="text-muted">Monitor and optimize your cloud spending</p>
        </div>
        <button className="btn btn-secondary">
          Export Report
        </button>
      </div>
      
      <div className="metrics-grid mb-24">
        <div className="metric-card">
          <div className="metric-value">${totalToday.toFixed(2)}</div>
          <div className="metric-label">Today</div>
          <div className="metric-change positive">-2% vs yesterday</div>
        </div>
        <div className="metric-card">
          <div className="metric-value">${totalWeek.toFixed(2)}</div>
          <div className="metric-label">This Week</div>
          <div className="metric-change positive">-5% vs last week</div>
        </div>
        <div className="metric-card">
          <div className="metric-value">${totalMonth.toFixed(2)}</div>
          <div className="metric-label">This Month</div>
          <div className="metric-change positive">-8% vs last month</div>
        </div>
        <div className="metric-card">
          <div className="metric-value">{instances.length}</div>
          <div className="metric-label">Active Resources</div>
        </div>
      </div>
      
      <div className="card mb-24">
        <div className="card-header">
          <h3 className="card-title">Cost Trend (Last 30 Days)</h3>
        </div>
        <div className="card-body">
          <div className="chart-container">
            <canvas ref={chartRef}></canvas>
          </div>
        </div>
      </div>
      
      <div className="card">
        <div className="card-header">
          <h3 className="card-title">Cost Breakdown by Instance</h3>
        </div>
        <div className="table-container">
          <table className="table">
            <thead>
              <tr>
                <th>Instance</th>
                <th>Provider</th>
                <th>Type</th>
                <th>Region</th>
                <th>Cost/Hour</th>
                <th>Daily Cost</th>
                <th>Monthly Est.</th>
              </tr>
            </thead>
            <tbody>
              {instances.map(instance => (
                <tr key={instance.id}>
                  <td className="font-medium">{instance.id}</td>
                  <td>{instance.provider}</td>
                  <td>{instance.type}</td>
                  <td>{instance.region}</td>
                  <td>${instance.costPerHour}</td>
                  <td>${(instance.costPerHour * 24).toFixed(2)}</td>
                  <td>${(instance.costPerHour * 24 * 30).toFixed(2)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

// Settings Component
function Settings() {
  const { showToast } = useContext(ToastContext);
  const [awsCredentials, setAwsCredentials] = useState({ accessKey: '', secretKey: '', region: 'us-east-1' });
  const [gcpCredentials, setGcpCredentials] = useState({ projectId: '', keyFile: '' });

  const handleSaveAws = (e) => {
    e.preventDefault();
    showToast('AWS credentials saved successfully', 'success');
  };

  const handleSaveGcp = (e) => {
    e.preventDefault();
    showToast('GCP credentials saved successfully', 'success');
  };

  return (
    <div>
      <div className="mb-24">
        <h2>Settings</h2>
        <p className="text-muted">Configure your cloud provider credentials and preferences</p>
      </div>
      
      <div className="flex flex-col gap-24">
        <div className="card">
          <div className="card-header">
            <h3 className="card-title">AWS Credentials</h3>
          </div>
          <div className="card-body">
            <form onSubmit={handleSaveAws}>
              <div className="form-group">
                <label className="form-label">Access Key ID</label>
                <input 
                  type="text"
                  className="form-input"
                  value={awsCredentials.accessKey}
                  onChange={(e) => setAwsCredentials({...awsCredentials, accessKey: e.target.value})}
                  placeholder="AKIA...."
                />
              </div>
              <div className="form-group">
                <label className="form-label">Secret Access Key</label>
                <input 
                  type="password"
                  className="form-input"
                  value={awsCredentials.secretKey}
                  onChange={(e) => setAwsCredentials({...awsCredentials, secretKey: e.target.value})}
                  placeholder="Enter secret key"
                />
              </div>
              <div className="form-group">
                <label className="form-label">Default Region</label>
                <select 
                  className="form-input"
                  value={awsCredentials.region}
                  onChange={(e) => setAwsCredentials({...awsCredentials, region: e.target.value})}
                >
                  {cloudRegions.aws.map(region => (
                    <option key={region.code} value={region.code}>{region.name}</option>
                  ))}
                </select>
              </div>
              <button type="submit" className="btn btn-primary">Save AWS Credentials</button>
            </form>
          </div>
        </div>
        
        <div className="card">
          <div className="card-header">
            <h3 className="card-title">Google Cloud Credentials</h3>
          </div>
          <div className="card-body">
            <form onSubmit={handleSaveGcp}>
              <div className="form-group">
                <label className="form-label">Project ID</label>
                <input 
                  type="text"
                  className="form-input"
                  value={gcpCredentials.projectId}
                  onChange={(e) => setGcpCredentials({...gcpCredentials, projectId: e.target.value})}
                  placeholder="my-project-123"
                />
              </div>
              <div className="form-group">
                <label className="form-label">Service Account Key File</label>
                <input 
                  type="file"
                  className="form-input"
                  accept=".json"
                />
              </div>
              <button type="submit" className="btn btn-primary">Save GCP Credentials</button>
            </form>
          </div>
        </div>
        
        <div className="card">
          <div className="card-header">
            <h3 className="card-title">Security Settings</h3>
          </div>
          <div className="card-body">
            <div className="form-group">
              <div className="form-checkbox">
                <input type="checkbox" className="checkbox" />
                <label className="checkbox-label">Enable two-factor authentication</label>
              </div>
            </div>
            <div className="form-group">
              <label className="form-label">Session Timeout</label>
              <select className="form-input">
                <option>15 minutes</option>
                <option>30 minutes</option>
                <option>1 hour</option>
                <option>4 hours</option>
              </select>
            </div>
            <button className="btn btn-primary">Save Security Settings</button>
          </div>
        </div>
      </div>
    </div>
  );
}

// Main Dashboard Layout
function DashboardLayout() {
  const { currentPage } = useContext(AppContext);

  const renderPage = () => {
    const pageConfig = {
      dashboard: { component: Dashboard, title: 'Dashboard' },
      map: { component: WorldMap, title: 'World Map' },
      fleet: { component: FleetManager, title: 'Fleet Manager' },
      vpn: { component: VpnDashboard, title: 'VPN Dashboard' },
      workloads: { component: WorkloadScheduler, title: 'Workload Scheduler' },
      costs: { component: CostTracker, title: 'Cost Tracker' },
      settings: { component: Settings, title: 'Settings' }
    };

    const config = pageConfig[currentPage] || pageConfig.dashboard;
    const Component = config.component;
    
    return (
      <>
        <Header title={config.title} />
        <div className="main-body">
          <Component />
        </div>
      </>
    );
  };

  return (
    <div className="dashboard-layout">
      <Sidebar />
      <div className="main-content">
        {renderPage()}
      </div>
    </div>
  );
}

// Main App Component
function App() {
  const { isAuthenticated, loading } = useContext(AuthContext);

  if (loading) {
    return (
      <div className="login-container">
        <div className="spinner"></div>
      </div>
    );
  }

  return isAuthenticated ? <DashboardLayout /> : <LoginPage />;
}

// Root App with Providers
function RootApp() {
  return (
    <ToastProvider>
      <AuthProvider>
        <AppProvider>
          <App />
        </AppProvider>
      </AuthProvider>
    </ToastProvider>
  );
}

// Render the app
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(React.createElement(RootApp));
